package com.lionxcr.real.time.tracker;


import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;

public class RnRealTimeTrackerModule extends ReactContextBaseJavaModule {

    private final ReactApplicationContext reactContext;


    public RnRealTimeTrackerModule(ReactApplicationContext reactContext) {
        super(reactContext);
        this.reactContext = reactContext;
    }

    @Override
    public String getName() {
        return "RnRealTimeTracker";
    }

//    @ReactMethod
//    public void startGPS(String title, String description, String settingButton, String cancelButton) {
//        gpsTracker.startLocationService(title, description, settingButton, cancelButton);
//    }

}
